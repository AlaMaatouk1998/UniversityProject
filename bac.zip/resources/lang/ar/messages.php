<?php

return [

    /*
        Version Arabe
    */
    'nav_home' => 'إستقبال',
    'home_prive' => 'الخاص',
    'home_publique' => 'العمومي',
    'recherche_avancee' => 'بحث متقدم',
    'contact' => 'الاتصال',
    'connexion' => 'تسجيل دخول',
    'home_title' => "شطرا",
    'home_description' => " كلام كلام ion la liste exhaustive de tous les établissements en Tunisie ainsi que toutes les informations relatives à un cursus universitaire pour vous orienter et vous guider dans vos choix pour vous garantir un avenir meilleur.",
    'home_action_btn' => 'ابدا',
    'home_etablissement_title' => 'الكليات',
    'home_etablissement_description' => "Exploiter les formations disponibles dans un affichage guidé.",
    'home_formations_label' => 'دراسات',
    'home_etablissements_label' => 'الكليات',
    'home_statistiques_label' => 'إحصائيات',
    'universite_label' => 'جامعات'
    
];
