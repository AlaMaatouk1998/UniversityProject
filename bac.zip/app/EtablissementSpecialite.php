<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EtablissementSpecialite extends Model
{
    protected $table = "etablissement_specialite";
}
